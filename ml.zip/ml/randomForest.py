import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, normalize
from sklearn.ensemble import RandomForestClassifier
import warnings

warnings.filterwarnings('ignore')

class RandomForestModel:
    x_train, x_test, y_train, y_test, x_val, y_val, RF  = None, None, None, None, None, None, None
    RF_best, params_best = None, None
    param_grid = [{
        'n_estimators': [100, 200, 300],
        'max_depth': [None, 5, 10, 20],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4],
        'max_features': ['sqrt', 'log2', None]
    }]

    def __init__(self, data):
        self.data = data

    def preprocess(self):
        base_cols = [col for col in self.data.columns if (col.startswith('R') or col.startswith('P')) and col != 'Peso do sistema']
        all_cols = base_cols + ['Delta yaw neutro']
        x = self.data[all_cols].copy()
        y = x.pop('Delta yaw neutro').values
        normalized_x = StandardScaler().fit(x).transform(x)
        return normalized_x, y

    def split_data(self, test_size=0.2, val_size=0.2, random_state=4):
        x, y = self.preprocess()
        x_temp, x_test, y_temp, y_test = train_test_split(x, y, test_size=test_size, random_state=random_state)
        val_relative_size = val_size / (1 - test_size)
        x_train, x_val, y_train, y_val = train_test_split(x_temp, y_temp, test_size=val_relative_size, random_state=random_state)
        self.x_train, self.x_val, self.x_test = x_train, x_val, x_test
        self.y_train, self.y_val, self.y_test = y_train, y_val, y_test
        return x_train, x_val, x_test, y_train, y_val, y_test

    def train(self):
        if self.x_train is None or self.y_train is None:
            self.split_data()
        self.RF = RandomForestClassifier(random_state=4).fit(self.x_train, self.y_train)
        return self.RF

    def train_with_grid(self):
        model = RandomForestClassifier(random_state=4)
        clf = GridSearchCV(model, param_grid=self.param_grid, cv=3, verbose=True, n_jobs=-1)
        self.RF_best = clf.fit(self.x_train, self.y_train)
        self.params_best = self.RF_best.best_params_
        return self.RF_best, self.params_best

    def predict(self):
        return self.RF.predict(self.x_test)

    def predict_with_grid(self):
        return self.RF_best.predict(self.x_test)
