import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
import warnings
warnings.filterwarnings('ignore')

class LogisticRegressionModel:
    x_train, x_test, y_train, y_test, x_val, y_val, LR  = None, None, None, None, None, None, None
    LR_best, params_best = None, None
    param_grid = [{
        'penalty':['l1','l2','elasticnet','none'],
        'C' : np.logspace(-4,4,20),
        'solver': ['lbfgs','newton-cg','liblinear','sag','saga'],
        'max_iter'  : [100,1000,2500,5000],
        'tol': [0.0001, 0.001, 0.01, 0.1, 1]    
    }]
    
    def __init__(self, data):
        self.data = data
    

    def preprocess(self):
        base_cols = [col for col in self.data.columns if (col.startswith('R') or col.startswith('P')) and col != 'Peso do sistema']
        all_cols = base_cols + ['Delta yaw neutro']
        x = self.data[all_cols].copy()
        y = x.pop('Delta yaw neutro').values
        normalized_x = StandardScaler().fit(x).transform(x)
        return normalized_x, y


    def split_data(self, test_size=0.2, val_size=0.2, random_state=4):
        x, y = self.preprocess()
        # First split off test set
        x_temp, x_test, y_temp, y_test = train_test_split(x, y, test_size=test_size, random_state=random_state)
        # Then split temp into train and validation
        val_relative_size = val_size / (1 - test_size)
        x_train, x_val, y_train, y_val = train_test_split(x_temp, y_temp, test_size=val_relative_size, random_state=random_state)
        self.x_train, self.x_val, self.x_test = x_train, x_val, x_test
        self.y_train, self.y_val, self.y_test = y_train, y_val, y_test
        return x_train, x_val, x_test, y_train, y_val, y_test

    def train(self):
        if self.x_train is None or self.y_train is None:
            self.split_data()
        self.LR = LogisticRegression(random_state=4).fit(self.x_train, self.y_train)
        return self.LR
    
    def train_with_grid(self):
        model = LogisticRegression()
        clf = GridSearchCV(model,param_grid = self.param_grid, cv = 3, verbose=True,n_jobs=-1)
        self.LR_best = clf.fit(self.x_train,self.y_train)
        self.params_best = self.LR_best.best_params_
        return self.LR_best, self.params_best
    
    def predict(self):
        return self.LR.predict(self.x_test)
    
    def predict_with_grid(self):
        return self.LR_best.predict(self.x_test)
        
    
